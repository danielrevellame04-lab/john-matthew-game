# John Matthew 3D Co-op Game

A browser-based 3-player cooperative 3D puzzle prototype.

## Run locally
1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run:
   npm install
   npm start
4. Open http://localhost:3000
5. Open the URL in three browser tabs/devices on the same reachable server.
6. Enter a username and choose Blind, Can't Speak, or Can't Hear.
7. When 3 players have joined, Start Game becomes available.

## Online hosting
Deploy the folder to a Node.js host that supports WebSockets (Socket.IO), then share the HTTPS URL.

## Controls
- WASD / arrow keys: move
- Mouse drag / touch drag: rotate camera
- Hand panel: choose ✌️ 👍 👎 🫱 ✊ 👋 🫵
- TTS button: speaks the typed message using browser speech synthesis
- 🎙️ WebRTC microphone voice chat: players can hear each other in real time
- Can't Hear: incoming voice is blocked
- Can't Speak: microphone is disabled
- Blind role: screen uses grayscale + eye cover; the player cannot rely on colors.
- Can't Speak: mouth cover and chat is blocked; hand signs remain available.
- Can't Hear: headphones and incoming chat is hidden.
- Wire puzzle: the team must communicate which wire to cut. Three successful rounds wins.

This is a prototype: authoritative anti-cheat, persistent accounts, matchmaking, voice chat, and production hosting are not included.


## Microphone
The browser will ask for microphone permission when Mic On is pressed. For remote HTTPS hosting, use HTTPS because browsers generally require a secure context for microphone access. Voice uses WebRTC with a public STUN server for peer connection setup.
