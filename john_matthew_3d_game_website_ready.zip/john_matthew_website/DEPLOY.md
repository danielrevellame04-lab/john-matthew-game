# Put the game online

This game is a Node.js + Socket.IO multiplayer website, so it needs a web host that can run Node.js. A static-only host such as ordinary GitHub Pages cannot run the Socket.IO server.

## Easiest route

1. Put this folder into a GitHub repository.
2. Connect that repository to a Node.js web host such as Render.
3. The included `render.yaml` already contains the build and start commands.
4. Deploy it.
5. Open the HTTPS URL on your phone in Chrome.
6. Give Chrome microphone permission when asked.
7. Send the same URL to the other two players.

The HTTPS URL is important for browser microphone/WebRTC permissions.

## Player flow

Open URL → enter username → choose role → wait for 3 players → Play → use mic/controls.
