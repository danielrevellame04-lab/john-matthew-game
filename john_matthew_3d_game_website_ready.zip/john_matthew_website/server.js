
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "public")));

let players = {};

io.on("connection", (socket) => {
  players[socket.id] = {
    id: socket.id,
    name: "Player",
    role: null,
    x: 0, z: 0, ry: 0,
    hand: "✋",
    speaking: false
  };

  socket.emit("welcome", { id: socket.id });
  io.emit("players", Object.values(players));

  socket.on("join", ({name, role}) => {
    players[socket.id].name = String(name || "Player").slice(0, 18);
    players[socket.id].role = ["blind","mute","deaf"].includes(role) ? role : null;
    io.emit("players", Object.values(players));
    io.emit("system", `${players[socket.id].name} joined as ${players[socket.id].role || "unassigned"}.`);
  });

  socket.on("move", (data) => {
    const p = players[socket.id];
    if (!p) return;
    p.x = Number(data.x) || 0;
    p.z = Number(data.z) || 0;
    p.ry = Number(data.ry) || 0;
    io.emit("playerMove", {id: socket.id, x:p.x, z:p.z, ry:p.ry});
  });

  socket.on("hand", (emoji) => {
    if (!players[socket.id]) return;
    players[socket.id].hand = String(emoji).slice(0, 2);
    io.emit("playerHand", {id: socket.id, hand: players[socket.id].hand});
  });

  socket.on("speakState", (speaking) => {
    if (!players[socket.id]) return;
    players[socket.id].speaking = !!speaking;
    io.emit("playerSpeakState", {id: socket.id, speaking: !!speaking});
  });

  socket.on("message", (msg) => {
    const p = players[socket.id];
    if (!p || p.role === "mute") return;
    const clean = String(msg || "").slice(0, 180);
    if (clean) io.emit("message", {id:socket.id, name:p.name, role:p.role, text:clean});
  });

  socket.on("cut", ({index}) => {
    io.emit("cutAttempt", {id:socket.id, index:Number(index)});
  });


  socket.on("voice-ready", () => {
    const ids = Object.keys(players).filter(id => id !== socket.id);
    socket.emit("voice-peers", ids);
    ids.forEach(id => io.to(id).emit("voice-peer-list", Object.keys(players).filter(x => x !== id)));
  });

  socket.on("voice-offer", ({to, offer}) => {
    if (players[to]) io.to(to).emit("voice-offer", {from:socket.id, offer});
  });

  socket.on("voice-answer", ({to, answer}) => {
    if (players[to]) io.to(to).emit("voice-answer", {from:socket.id, answer});
  });

  socket.on("voice-ice", ({to, candidate}) => {
    if (players[to]) io.to(to).emit("voice-ice", {from:socket.id, candidate});
  });

  socket.on("disconnect", () => {
    delete players[socket.id];
    io.emit("voice-peer-left", {id: socket.id});
    io.emit("players", Object.values(players));
    io.emit("system", "A player left the game.");
  });
});

server.listen(PORT, () => console.log(`Game server running at http://localhost:${PORT}`));
